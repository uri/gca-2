Multi-D Soccer Controls:

Left Half (Movement)
	- press and hold then drag either right or left to move

Right Half (Special_
	- WHILE MOVING tap to jump
	- swipe right or left to rotate the entire map to reveal new paths (in Multi-D lol)